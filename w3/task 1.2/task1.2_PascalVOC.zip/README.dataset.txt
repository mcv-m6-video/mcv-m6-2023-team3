# M6 > 2023-03-29 1:53am
https://universe.roboflow.com/uab-lnxbz/m6-lbhfk

Provided by a Roboflow user
License: CC BY 4.0

